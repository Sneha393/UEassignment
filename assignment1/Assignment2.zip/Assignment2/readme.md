home.html is the main page
resume.html,projects.html,certification.html consists all the details.
test1.css,test3.css are the css files
used media queries in test3.css
used column layout structure in projects.html
used absolute and relative position in home.html
float and overflow tags used
hover effect is used in menu 
table format is used in resume
form,button and contact information is added in footer
summary is used in home page
video is used in projects


